++++++++++++++++++         PHI = 359.00 DEGREES         ++++++++++++++++++++







   ++++++++++++++++++         THETA =  90.00 DEGREES         ++++++++++++++++++





               THE SCATTERING DIRECTION IS GIVEN INSIDE THE CRYSTAL
       THE POSITIONS OF THE ATOMS ARE GIVEN WITH RESPECT TO THE ABSORBER

          PHOTOELECTRON EXTERNAL THETA  =  90.00     INTERNAL THETA =  90.00



    ..........  DIRECTION OF THE DETECTOR      : ( 1.000,-0.018, 0.000)  ..........
                DIRECTION OF THE LIGHT         : ( 0.000,-0.000,-1.000)
                DIRECTION OF THE POLARIZATION  : ( 1.000, 0.000, 0.000)
                ANALYZER.LIGHT                 :         0.0000




   ++++++++++++++++++         PHI = 360.00 DEGREES         ++++++++++++++++++++







   ++++++++++++++++++         THETA =  90.00 DEGREES         ++++++++++++++++++





               THE SCATTERING DIRECTION IS GIVEN INSIDE THE CRYSTAL
       THE POSITIONS OF THE ATOMS ARE GIVEN WITH RESPECT TO THE ABSORBER

          PHOTOELECTRON EXTERNAL THETA  =  90.00     INTERNAL THETA =  90.00



    ..........  DIRECTION OF THE DETECTOR      : ( 1.000,-0.000, 0.000)  ..........
                DIRECTION OF THE LIGHT         : ( 0.000,-0.000,-1.000)
                DIRECTION OF THE POLARIZATION  : ( 1.000, 0.000, 0.000)
                ANALYZER.LIGHT                 :         0.0000





########## END OF THE POLAR PHOTOELECTRON DIFFRACTION CALCULATION ##########



