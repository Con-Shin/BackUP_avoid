import os
#from watchdog.observers import Observer
#from watchdog.events import FileSystemEventHandler
#from update_ipol import watch_and_modify_spec_dat  # 新たに追加するモジュール
#from time import sleep
from msspec.iodata import Data
from ase  import Atom, Atoms
import numpy as np
from msspec.calculator import MSSPEC
from msspec.utils import *
from ase.visualize import view
import shutil
from msspec.looper import Sweep, Looper

# spec.datを監視し、IPOLを手動で設定するための関数
def after_ipol_set():
    print("IPOL設定後の処理を続けます。")

do_CO = True
do_OC = False

#光電子の飛び出す軌道
level = '1s'

calc = MSSPEC(spectroscopy = 'PED',algorithm = 'inversion', polarization="linear_xOy", folder = 'calc')

#watch_and_modify_spec_dat(calc_directory, spec_file, ipol_value=1, callback_function=after_ipol_set)

#calc = _PED(algorithm = 'inversion', polarization='linear_xOy')

############# 分子を視覚的にみる場合は以下を追加#############
#view(NO)
#eixt(0)
#############################################################

#calc.global_parameters.bind_spinpol = True

# 散乱回数、今回は逆行列法のため本当は意味ない.
#calc.calculation_parameters.scattering_order = 2

#calc.global_parameters.algorithm = "expansion"

#filters = []

#filters.append('distance_cutoff')
#calc.calculation_parameters.distance = 100

#calc.calculation_parameters.path_filtering   = filters

# 偏光ベクトルの向き
#calc.global_parameters.polarization = linear_xOy # ‘linear_qOz’ for a polarization vector in the (qOz) plane

#lmaxを設定する際の宣言文
calc.tmatrix_parameters.lmax_mode = "imposed"

# lmaxの値
calc.tmatrix_parameters.lmaxt = 5

#Muffin-tin球の重なり. 原子の球体の重なり具合を調整する. 0.0<=x<=1.0で、値は重なりのパーセンテージ.
calc.muffintin_parameters.radius_overlapping = 0.0

#吸収原子がコアホールの周りでリラックスすることを許可するかどうか決定する.
calc.muffintin_parameters.charge_relaxation = True

#交換・相関ポテンシャル. Inelastic effectを反映.
calc.tmatrix_parameters.exchange_correlation = "hedin_lundqvist_real"

radii = (('C', 0.56789),('O', 0.56011))

#incident light energy and angle
calc.source_parameters.energy = 401.60    # 0 <= value
calc.source_parameters.theta = 90           # -180.0 <= value <= 180.0
calc.source_parameters.phi = -90            # -180.0 <= value <= 180.0

#各サイト周りの波動関数を展開する際の基底関数の記述する時の、基底関数の球形度.
calc.calculation_parameters.RA_cutoff = 2

def compute_scan(phi,theta,level,ke):

    all_data = calc.get_theta_scan(phi=phi, theta=theta, level=level, kinetic_energy=ke)
    return all_data

if do_CO:

#    NO = Atoms([Atom("N", position = (0.0000000000, 0.0000000000, 0.0000000000)), Atom("O", position = (0.0000000000, 0.0000000000, 1.1508)) ])
    CO = Atoms([Atom("O", position = (1.1282000000, 0.0000000000, 0.0000000000)), Atom("C", position = (0.0000000000, 0.0000000000, 0.0000000000)) ])

    CO.absorber = get_atom_index(CO,0.0000000000, 0.0000000000, 0.0000000000)

    calc.set_atoms(CO)

    #Muffintin半径を設定.
    for s, r in radii:
        [atom.set('mt_radius',r) for atom in CO if atom.symbol == s]
    
    Result = "Result_CO"

    all_data = None

    all_data = compute_scan(np.arange(0,361,1), 90,'1s', 156.18)

    # 観察するディレクトリとファイル
#    calc_directory = os.path.join(os.getcwd(), 'calc', 'input')  # 例えばcalc/inputディレクトリ
#    spec_file = 'spec.dat'  # 監視するファイル名

    # 監視を開始し、IPOLを1に設定する
#    watch_and_modify_spec_dat(calc_directory, spec_file, ipol_value=1, callback_function=after_ipol_set)

    all_data.export(os.path.join(Result, 'results'))
#    all_data.export(os.path.join(Result, 'results'))
    fn = os.path.join(Result, 'data.hdf5')
    all_data.save(fn)
    dset = all_data[-1]

if do_OC:

    OC = Atoms([Atom("C", position = (0.0000000000, 0.0000000000, 0.0000000000)), Atom("O", position = (1.12820000000, 0.0000000000, 0.0000000000)) ])

#    NO = Atoms([Atom("N", position = (0.0000000000, 0.0000000000, 0.0000000000)), Atom("O", position = (0.0000000000, 0.0000000000, 1.1508)) ])
#    ON.absorber = get_atom_index(ON,0.0000000000, 0.0000000000, 0.0000000000)
    
#    ON.rotate(180, 'x')

#    ON = Atoms([Atom("N", position = (0.0000000000, 0.0000000000, 0.0000000000)), Atom("O", position = (0.0000000000, 0.0000000000, -1.1508)) ])

    OC.absorber = get_atom_index(OC,0.0000000000, 0.0000000000, 0.0000000000)

    calc.set_atoms(OC)

    #Muffintin半径を設定.
    for s, r in radii:
        [atom.set('mt_radius',r) for atom in ON if atom.symbol == s]
#        print(s, r)
#    exit(0)

    Result = "Result_OC_SE"

    all_data = None

    all_data = compute_scan(np.arange(0,361,1), 90,'1s', 150)

#    all_data.export(os.path.join(Result, 'results'))
    all_data.export(os.path.join(Result, 'results'))
#        fn = os.path.join(Result, 'sweep{:02d}.hdf5'.format(isweep))
#        all_data.save(fn)
    dset = all_data[-1]

