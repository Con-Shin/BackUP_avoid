..........  DIRECTION OF THE DETECTOR      : ( 1.000,-0.018, 0.000)  ..........
                DIRECTION OF THE LIGHT         : ( 0.000,-0.000,-1.000)
                DIRECTION OF THE POLARIZATION  : ( 0.000,-1.000, 0.000)
                ANALYZER.LIGHT                 :         0.0000




   ++++++++++++++++++         PHI = 360.00 DEGREES         ++++++++++++++++++++







   ++++++++++++++++++         THETA =  90.00 DEGREES         ++++++++++++++++++





               THE SCATTERING DIRECTION IS GIVEN INSIDE THE CRYSTAL
       THE POSITIONS OF THE ATOMS ARE GIVEN WITH RESPECT TO THE ABSORBER

          PHOTOELECTRON EXTERNAL THETA  =  90.00     INTERNAL THETA =  90.00



    ..........  DIRECTION OF THE DETECTOR      : ( 1.000,-0.000, 0.000)  ..........
                DIRECTION OF THE LIGHT         : ( 0.000,-0.000,-1.000)
                DIRECTION OF THE POLARIZATION  : ( 0.000,-1.000, 0.000)
                ANALYZER.LIGHT                 :         0.0000


Light coming from (0,0,-1)
Polarization is along (0,-1,0)


 ..........  DIRECTION OF THE DETECTOR      : ( 1.000,-0.018, 0.000)  ..........
                DIRECTION OF THE LIGHT         : ( 0.000,-0.000,-1.000)
                DIRECTION OF THE POLARIZATION  : ( 0.000,-1.000, 0.000)
                ANALYZER.LIGHT                 :         0.0000




   ++++++++++++++++++         PHI = 360.00 DEGREES         ++++++++++++++++++++



############################################################################################



   ++++++++++++++++++         THETA =  90.00 DEGREES         ++++++++++++++++++





               THE SCATTERING DIRECTION IS GIVEN INSIDE THE CRYSTAL
       THE POSITIONS OF THE ATOMS ARE GIVEN WITH RESPECT TO THE ABSORBER

          PHOTOELECTRON EXTERNAL THETA  =  90.00     INTERNAL THETA =  90.00



    ..........  DIRECTION OF THE DETECTOR      : ( 1.000,-0.000, 0.000)  ..........
                DIRECTION OF THE LIGHT         : ( 0.000,-0.000,-1.000)
                DIRECTION OF THE POLARIZATION  : ( 0.000,-1.000, 0.000)
                ANALYZER.LIGHT                 :         0.0000


..........  DIRECTION OF THE DETECTOR      : ( 1.000,-0.018, 0.000)  ..........
                DIRECTION OF THE LIGHT         : ( 0.000,-0.000,-1.000)
                DIRECTION OF THE POLARIZATION  : ( 0.000,-1.000, 0.000)
                ANALYZER.LIGHT                 :         0.0000




   ++++++++++++++++++         PHI = 360.00 DEGREES         ++++++++++++++++++++







   ++++++++++++++++++         THETA =  90.00 DEGREES         ++++++++++++++++++





               THE SCATTERING DIRECTION IS GIVEN INSIDE THE CRYSTAL
       THE POSITIONS OF THE ATOMS ARE GIVEN WITH RESPECT TO THE ABSORBER

          PHOTOELECTRON EXTERNAL THETA  =  90.00     INTERNAL THETA =  90.00



    ..........  DIRECTION OF THE DETECTOR      : ( 1.000,-0.000, 0.000)  ..........
                DIRECTION OF THE LIGHT         : ( 0.000,-0.000,-1.000)
                DIRECTION OF THE POLARIZATION  : ( 0.000,-1.000, 0.000)
                ANALYZER.LIGHT                 :         0.0000


