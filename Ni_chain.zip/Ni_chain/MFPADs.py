import numpy as np
import matplotlib.pyplot as plt

# テキストファイルのデータを読み込む関数
def load_cross_section_data(filename_NO,  theta_value):
    phi_values_NO = []
    cross_section_values_NO = []
    with open(filename_NO, 'r') as file:
        for line in file:
            if line.startswith('#'):
                continue
            data = line.strip().split()
#            print(data)
#            exit(0)
            if len(data) < 3:
#                print(len(data))
#                exit(0)
                continue
            theta = float(data[0])
#            print(phi)
            phi = float(data[1])
#            print(theta)
            cross_section = float(data[3])
#            print(cross_section)
            if theta == theta_value:
#                theta_values_NO.append(np.radians(theta))  # θをラジアンに変換
                phi_values_NO.append(np.radians(phi))
                cross_section_values_NO.append(cross_section)
#                theta_values.append(theta)
#                cross_section_values.append(cross_section)
    
#    theta_values_ON = []
#    cross_section_values_ON = []
#    with open(filename_ON, 'r') as file:
#        for line in file:
#            if line.startswith('#'):
#                continue
#            data = line.strip().split()
#            print(data)
#            exit(0)
#            if len(data) < 3:
#                print(len(data))
#                exit(0)
#                continue
#            theta = float(data[0])
#            print(phi)
#            phi = float(data[1])
#            print(theta)
#            cross_section = float(data[3])
#            print(cross_section)
#            if phi == phi_value:
#                theta_values_ON.append(np.radians(theta))  # θをラジアンに変換
#                cross_section_values_ON.append(cross_section)
#                print(cross_section)
#                exit(0)
#                theta_values.append(theta)
#                cross_section_values.append(cross_section)

    return phi_values_NO, cross_section_values_NO

def plot_polar_cross_section_sequential(phi_values_NO, cross_section_values_NO, theta_value):
    fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
    ax.set_title(f'Cross Section for theta={theta_value}°')
    ax.set_theta_zero_location("N")  # 0°を北に設定
    ax.set_theta_direction(-1)       # 時計回りに設定
    ax.set_rlabel_position(0)        # 半径ラベルの位置を設定

#    for i in range(len(theta_values_ON)):

#        theta_values_ON[i] = theta_values_NO[i] + np.pi

#    print(theta_values_ON)
#    print(theta_values_NO)
#    exit(0)

    # 各点を前の点と結びながらプロット
    for i in range(1, len(phi_values_NO)):
        # 各セグメントごとにプロットして前の点と結ぶ
        ax.plot(phi_values_NO[i-1:i+1], cross_section_values_NO[i-1:i+1], color='b', marker='o', markersize=3)
#        ax.plot(theta_values_ON[i-1:i+1], cross_section_values_ON[i-1:i+1], color='b', marker='o', markersize=3)

    plt.legend([f'theta={theta_value}°'])
    plt.show()

# ファイルパスと読み込み角度の設定
filename_NO = 'Result_Ni_SE_pol_z/results/phi_scan_[0]/phi_scan_[0].txt'
#bilayer.absorber = 
#filename_ON = 'Result_ON/results/theta_scan_[0]/theta_scan_[0].txt'

# phi = 0°のデータをプロット
phi_values_NO_0, cross_section_values_NO_0 = load_cross_section_data(filename_NO, theta_value=90)
#print(theta_values_NO_0)
#print(theta_values_ON_0)
#exit(0)

#print(cross_section_values_0)
#exit(0)
plot_polar_cross_section_sequential(phi_values_NO_0, cross_section_values_NO_0, theta_value=90)

# phi = 90°のデータをプロット
#theta_values_90, cross_section_values_90 = load_cross_section_data(filename, phi_value=90)
#plot_polar_cross_section_sequential(theta_values_90, cross_section_values_90, phi_value=90)
